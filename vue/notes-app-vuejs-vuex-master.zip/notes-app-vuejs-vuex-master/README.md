# Learn Vuex by Building a Notes App

This code is for the tutorial on building a Notes App using VueJs and Vuex

Check out the full tutorial on [coligo](http://coligo.io/learn-vuex-by-building-notes-app/)

### Install the dependencies

```bash
npm install
```

### Run the dev server with hot reload at localhost:8080

```bash
npm run dev
```

### Build the app for production

```bash
npm run build
```
