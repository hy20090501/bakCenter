## 基于react+redux+react-router的实例 ##
文章说明地址：http://www.cnblogs.com/luozhihao/p/5660496.html
