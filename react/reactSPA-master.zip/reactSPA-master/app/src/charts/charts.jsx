import React from 'react';
import {Icon} from 'antd';

export default class Charts extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
      return (
        <Icon type="setting"/>
      );
    }
}

