import Reflux from 'reflux';
// 创建动作
let actions = Reflux.createActions(['increment']);

export default actions;