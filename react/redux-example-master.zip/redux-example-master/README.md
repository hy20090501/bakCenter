# redux-example

 使用Redux管理你的React应用。
 ![Manage Items](http://matthew-sun.github.io/images/manage-items.gif)
 
##使用
```
 1. npm install
 2. npm start
 3. open localhost:3000
```

##相关Blog
[使用Redux管理你的React应用](https://github.com/matthew-sun/blog/issues/18)
