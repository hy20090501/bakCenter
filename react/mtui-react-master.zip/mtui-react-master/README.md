# mtui-react

- node : v5.9.0
- npm : v3.7.3

####React MTUI 1.0版本:[UI地址](http://mtui.mtsee.com)


####命令说明：
- npm install 安装插件 
- npm build 打包发布(start-build.bat)

#####HOT开发模式(推荐)：
- 第一步启动服务器：npm server (start-server.bat)
- 第二步进入热开发：npm hot (start-dev-hot.bat)

#####普通开发模式：
- 页面刷新模式 npm start（start-dev-old.bat） 

tips:热开发模式和自动刷新模式二选一。

浏览器输入：localhost:3000

####目录结构：
- mtui-react
 + build `发布的文件`
 + dev `开发的文件`


@by 馒头
