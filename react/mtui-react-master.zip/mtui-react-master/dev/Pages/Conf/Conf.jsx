/**
* 全局变量的配置
* @author : Mantou
* @date : 2016-03-01
*/
let Conf = {
  pageAnimate : 'fadeInLeft animated' 
}
//配置信息
module.exports = Conf;