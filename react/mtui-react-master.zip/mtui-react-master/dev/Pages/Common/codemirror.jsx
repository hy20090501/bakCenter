import 'http://codemirror.net/lib/codemirror.css';
import 'http://codemirror.net/lib/codemirror.js';
import 'http://codemirror.net/addon/selection/selection-pointer.js';
import 'http://codemirror.net/mode/xml/xml.js';
import 'http://codemirror.net/mode/javascript/javascript.js';
import 'http://codemirror.net/mode/css/css.js';
import 'http://codemirror.net/mode/vbscript/vbscript.js';
import 'http://codemirror.net/mode/htmlmixed/htmlmixed.js';