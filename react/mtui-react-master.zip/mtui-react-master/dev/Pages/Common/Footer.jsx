/**
* footer
* @param : 输入
* @return : 返回
*/
import React from 'react'

const Footer = React.createClass({
  render() {
    return (
        <div className="footer">
            作者：Mantou&nbsp;&nbsp;&nbsp;
            QQ：676015863&nbsp;&nbsp;&nbsp;
            一款永久免费的React前端组件库
        </div>
    );
  }
});
//关于我们
module.exports = Footer;