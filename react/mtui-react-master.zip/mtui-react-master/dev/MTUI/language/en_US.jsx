const en_US = {
    'name':'My name is {name}, I\'m {age} years old!'
}   
export default en_US;