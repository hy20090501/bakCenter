const zh_CN = {
    'name':'我的名字叫：{name},我今年{age}岁！'
}
export default zh_CN;