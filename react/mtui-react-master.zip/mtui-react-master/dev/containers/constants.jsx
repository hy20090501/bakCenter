//reducer
export const SET_USER_INFO = 'SET_USER_INFO' //设置用户信息